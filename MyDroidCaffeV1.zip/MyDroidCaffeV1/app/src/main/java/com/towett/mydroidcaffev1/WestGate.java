package com.towett.mydroidcaffev1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class WestGate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_west_gate);

        TextView westTitle = findViewById(R.id.west_title);
        westTitle.setText(getIntent().getStringExtra("gTitle"));


        ImageView westImage = findViewById(R.id.west_image);
        Glide.with(this).load(getIntent().getIntExtra("gImage",0)).into(westImage);
    }
}